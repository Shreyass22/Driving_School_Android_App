package com.example.attendancemanagementsystem;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Objects;
import java.util.regex.Pattern;

public class Registration extends AppCompatActivity {
    private static final Pattern Password_Pattern =
            Pattern.compile("^" +
                    "(?=.*[0-9])" +         //at least 1 digit
                    "(?=.*[a-z])" +         //at least 1 lower case letter
                    "(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{4,}" +               //at least 4 characters
                    "$");


    private EditText username, email, password;
    private Button registerbtn;
    private RadioGroup radioGroup;
    private ProgressBar progess_bar;

    private FirebaseDatabase rootNode;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference reference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        //db Firebase instance
        rootNode = FirebaseDatabase.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();

        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        registerbtn = findViewById(R.id.registerbtn);
        registerbtn = findViewById(R.id.registerbtn);
        radioGroup = findViewById(R.id.rg);
        progess_bar = findViewById(R.id.progess_bar);
    }

    private Boolean validateName () {
        String val = username.getText().toString();
        if(val.isEmpty()) {
            username.setError("Field cannot be empty");
            return false;
        }
        else{
            username.setError(null);
            return true;
        }
    }

    private Boolean validateEmail () {
        String val = email.getText().toString();

        if(val.isEmpty()) {
            email.setError("Field cannot be empty");
            return false;
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(val).matches()) {
            email.setError("Enter valid E-mail");
            return false;
        }
        else{
            email.setError(null);
            return true;
        }
    }

    private Boolean validatePassword () {
        String val = password.getText().toString();
        if(val.isEmpty()) {
            password.setError("Field cannot be empty");
            return false;
        }
        else if (!Password_Pattern.matcher(val).matches()) {
            password.setError("Password is too weak");
            return false;
        }
        else{
            password.setError(null);
            return true;
        }
    }

    //save data in firebase on button click
    public void registerbtn(View view) {

        String name = username.getText().toString();
        String mail = email.getText().toString();
        String passwordd = password.getText().toString();

        int checkId = radioGroup.getCheckedRadioButtonId();
        RadioButton selected_type = (RadioButton) radioGroup.findViewById(checkId);
        if (selected_type == null) {
            Toast.makeText(Registration.this, "Select Type", Toast.LENGTH_SHORT).show();
        }
        else {
            final String type = selected_type.getText().toString();
            //validate
            if(!validateName() | !validateEmail() | !validatePassword()) {
                return;
            }
            else{
                register(name, mail, passwordd, type);
            }
        }
    }

    private void register(String name, String mail, String passwordd, String type) {
        progess_bar.setVisibility(View.VISIBLE);
        firebaseAuth.createUserWithEmailAndPassword(mail,passwordd).addOnCompleteListener(task -> {
            if(task.isSuccessful()) {
                FirebaseUser rUser = firebaseAuth.getCurrentUser(); //
                String userID = rUser.getUid();  //
                reference = rootNode.getReference("users").child(userID); //realtimedb
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("userId", userID);
                hashMap.put("name", name);
                hashMap.put("email", mail);
                hashMap.put("password", passwordd);
                hashMap.put("type", type);

                reference.setValue(hashMap).addOnCompleteListener(task1 -> {
                    progess_bar.setVisibility(View.GONE);
                    if (task1.isSuccessful()) {
                        Intent intent = new Intent(Registration.this, MainActivity.class);
                        Toast.makeText(Registration.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                        //firebaseAuth.signOut();

                    }
                    else {
                        Toast.makeText(Registration.this, Objects.requireNonNull(task1.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
            else {
                progess_bar.setVisibility(View.GONE);
                Toast.makeText(Registration.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
