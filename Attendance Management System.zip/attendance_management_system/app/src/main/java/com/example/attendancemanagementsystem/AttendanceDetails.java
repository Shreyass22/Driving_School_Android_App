package com.example.attendancemanagementsystem;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class AttendanceDetails {
    public String subjectName, totalAttended, totalLectures, attendancePercent;
    public  AttendanceDetails() {}

    public AttendanceDetails(String subjectName, String totalAttended, String totalLectures, String attendancePercent) {
        this.subjectName = subjectName;
        this.totalAttended = totalAttended;
        this.totalLectures = totalLectures;
        this.attendancePercent = attendancePercent;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        subjectName = subjectName;
    }

    public String getTotalAttended() {
        return totalAttended;
    }

    public String setTotalAttended(String totalAttended) {
        this.totalAttended = totalAttended;
        return totalAttended;
    }

    public String getTotalLectures() {
        return totalLectures;
    }

    public String setTotalLectures(String totalLectures) {
        this.totalLectures = totalLectures;
        return totalLectures;
    }

    public String getAttendancePercent() {
        return attendancePercent;
    }

    public String setAttendancePercent(String attendancePercent) {
        this.attendancePercent = attendancePercent;
        return attendancePercent;
    }



}
