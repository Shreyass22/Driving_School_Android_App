package com.example.attendancemanagementsystem.fragment;

import androidx.fragment.app.Fragment;

public class AboutUsFragment extends Fragment {
}
