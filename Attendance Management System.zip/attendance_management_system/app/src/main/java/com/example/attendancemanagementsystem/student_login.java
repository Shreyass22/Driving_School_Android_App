package com.example.attendancemanagementsystem;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class student_login extends AppCompatActivity {
    EditText mEmail, mPassword;
    Button loginbtn;
    TextView appTitle;
    FirebaseAuth fAuth;
    DatabaseReference databaseReference;
    ProgressBar progess_bar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);
        loginbtn = findViewById(R.id.loginbtn);
        mEmail = findViewById(R.id.email);
        appTitle = findViewById(R.id.title);
        mPassword = findViewById(R.id.password);
        progess_bar = findViewById(R.id.progess_barr);
        fAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();

//        if(fAuth.getCurrentUser() != null){
//            //that means user is already logged in
//            //so close this activity
//            finish();
//
//            //and open profile activity
//            startActivity(new Intent(getApplicationContext(), Student_dash.class));
//        }
    }

    private Boolean validateUsername() {
        String val = mEmail.getText().toString();
        if (val.isEmpty()) {
            mEmail.setError("Field cannot be empty");
            return false;
        } else {
            mEmail.setError(null);
            return true;
        }
    }

    private Boolean validatePassword() {
        String val = mPassword.getText().toString();
        if (val.isEmpty()) {
            mPassword.setError("Field cannot be empty");
            return false;
        } else {
            mPassword.setError(null);
            return true;
        }
    }

    //check validation
    public void login_btn(View view) {
        String userEnteredName = mEmail.getText().toString();
        String userEnteredPassword = mPassword.getText().toString();
        //validate
        if (!validateUsername() | !validatePassword()) {
            return;
        } else {
            login(userEnteredName, userEnteredPassword);
        }
    }

    private void login(String userEnteredName, String userEnteredPassword) {
        progess_bar.setVisibility(View.VISIBLE);
        //RDB
        fAuth.signInWithEmailAndPassword(userEnteredName, userEnteredPassword).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                FirebaseUser rUser = fAuth.getCurrentUser(); //
                String userID = rUser.getUid();  //
                databaseReference.child("users").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if (snapshot.child(userID).child("type").getValue(String.class).equals("Teacher")) {
                            startActivity(new Intent(getApplicationContext(), Teacher_dash.class));
                            finish();

                        } else if (snapshot.child(userID).child("type").getValue(String.class).equals("Student")) {
                            startActivity(new Intent(getApplicationContext(), Student_dash.class));
                            finish();

                        } else {
                            progess_bar.setVisibility(View.GONE);
                            Toast.makeText(student_login.this, "Email doesnot exist", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        progess_bar.setVisibility(View.GONE);
                        Toast.makeText(student_login.this, "ERROR : 404", Toast.LENGTH_SHORT).show();
                    }
                });

            } else {
                progess_bar.setVisibility(View.GONE);
                Toast.makeText(student_login.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    //onstart : when app starts
    @Override
    protected void onStart() {
        super.onStart();
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            FirebaseUser rUser = fAuth.getCurrentUser(); //
            String userID = rUser.getUid();  //
            databaseReference.child("users").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    if (snapshot.child(userID).child("type").getValue(String.class).equals("Admin")) {

                        startActivity(new Intent(getApplicationContext(), Teacher_dash.class));
                        finish();
                    } else if (snapshot.child(userID).child("type").getValue(String.class).equals("Student")) {

                        startActivity(new Intent(getApplicationContext(), Student_dash.class));
                        finish();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(student_login.this, "Database error", Toast.LENGTH_SHORT).show();
                }
            });
        }

    }


}
