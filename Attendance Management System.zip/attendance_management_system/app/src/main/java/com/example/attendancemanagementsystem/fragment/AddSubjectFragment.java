package com.example.attendancemanagementsystem.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.attendancemanagementsystem.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class AddSubjectFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final DatabaseReference myRef = FirebaseDatabase.getInstance().getReference();
        View rootView =  inflater.inflate(R.layout.fragment_addsubject,container,false);
        final TextView subName = rootView.findViewById(R.id.add_subname);
        final Button savebtn = (Button)rootView.findViewById(R.id.submit_button);
        savebtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                myRef.child("AttendanceDetails").child(subName.getText().toString()).child("subjectName").setValue(subName.getText().toString());
                subName.setText("");
                Toast.makeText(getActivity(),"Subject added sucessfully",Toast.LENGTH_LONG).show();
            }
        });


        return rootView;
    }
}
