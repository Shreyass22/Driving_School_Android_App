package com.example.attendancemanagementsystem.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.attendancemanagementsystem.AttendanceAdapter;
import com.example.attendancemanagementsystem.AttendanceDetails;
import com.example.attendancemanagementsystem.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MarkAttendanceFragment extends Fragment {
    RecyclerView recyclerView;
    CardView cardView;
    AttendanceDetails attendanceDetails;
    ArrayList<AttendanceDetails> details = new ArrayList<AttendanceDetails>();
    public TextView subname,attn,totalAttended,totalLecs,slash1,totalpercent;
    public ImageButton presentbtn, absentbtn;
    public ProgressBar attnbar;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView =  inflater.inflate(R.layout.fragment_mark_attendance,container,false);
        recyclerView = rootView.findViewById(R.id.attendance_recycler);
        cardView = rootView.findViewById(R.id.sub_cards);
        this.attnbar = rootView.findViewById(R.id.attn_progress);
        this.totalpercent = rootView.findViewById(R.id.attn_percent);
        this.subname =rootView.findViewById(R.id.subname);
        this.attn =rootView.findViewById(R.id.num_of_days);
        this.slash1 = rootView.findViewById(R.id.slash);
        this.totalAttended = rootView.findViewById(R.id.attended);
        this.totalLecs =rootView.findViewById(R.id.totallecs);
        this.presentbtn = rootView.findViewById(R.id.present);
        this.absentbtn = rootView.findViewById(R.id.absent);
        attendanceDetails = new AttendanceDetails();
        //final AttendanceDetails attendanceDetails = new AttendanceDetails(subname.getText().toString(),totalAttended.getText().toString(),totalLecs.getText().toString(),totalpercent.getText().toString());

        final DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("AttendanceDetails");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                details = new ArrayList<AttendanceDetails>();
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                for (DataSnapshot ds: dataSnapshot.getChildren()) {

                    attendanceDetails.setSubjectName(subname.getText().toString());
                    attendanceDetails.setTotalAttended(totalAttended.getText().toString());
                    attendanceDetails.setTotalLectures(totalLecs.getText().toString());
                    attendanceDetails.setAttendancePercent(totalpercent.getText().toString());
                    details.add(ds.getValue(AttendanceDetails.class));
                    myRef.child(subname.getText().toString()).setValue(attendanceDetails);
                    //Log.d("SNAPSHOT", ds.getValue(AttendanceDetails.class).SubjectName.toString());
                }

                Log.d("TAG", String.valueOf(details.size()));
                AttendanceAdapter adapter = new AttendanceAdapter(getActivity(),details);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });
        return rootView;
    }
}
