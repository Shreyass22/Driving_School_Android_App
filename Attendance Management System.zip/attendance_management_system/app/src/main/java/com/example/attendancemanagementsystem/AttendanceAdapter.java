package com.example.attendancemanagementsystem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.ViewHolder> {
    private ArrayList<AttendanceDetails> details;
    private Context context;
    double i,j;
    double attn_percent;
    AttendanceDetails attendanceDetails;
    final DatabaseReference myRef = FirebaseDatabase.getInstance().getReference();

    public AttendanceAdapter(Context context, ArrayList<AttendanceDetails> details) {
        this.details = details;
        this.context = context;
    }


    @NonNull
    @Override
    public AttendanceAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.semester_cards, parent, false);
        return new ViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(@NonNull final AttendanceAdapter.ViewHolder holder, int position) {
        final AttendanceDetails atndetails = details.get(position);
        holder.subname.setText(atndetails.getSubjectName());
        attendanceDetails = new AttendanceDetails();
        holder.attn.setText("Attendance: ");
        holder.slash1.setText("/");
        //myRef.child("AttendanceDetails").child(atndetails.getSubjectName()).child("subjectName").setValue(atndetails.getSubjectName());
        holder.presentbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i++; j++;
                holder.totalAttended.setText(atndetails.setTotalAttended(String.valueOf(((int)i))));
                holder.totalLecs.setText(atndetails.setTotalLectures(String.valueOf(((int)j))));
                attn_percent = ((i/j)*100);
                holder.attnbar.setProgress((int) attn_percent);
                holder.totalpercent.setText(atndetails.setAttendancePercent(String.valueOf((attn_percent))));
                myRef.child("AttendanceDetails").child(atndetails.getSubjectName()).child("totalAttended").setValue(atndetails.setTotalAttended(String.valueOf((int)i)));
                myRef.child("AttendanceDetails").child(atndetails.getSubjectName()).child("totalLecs").setValue(atndetails.setTotalLectures(String.valueOf((int)j)));
                myRef.child("AttendanceDetails").child(atndetails.getSubjectName()).child("attendancePercent").setValue(atndetails.setAttendancePercent(String.valueOf((int) attn_percent)));
            }
        });
        holder.absentbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                j++;
                holder.totalAttended.setText(atndetails.setTotalAttended(String.valueOf((int)i)));
                holder.totalLecs.setText(atndetails.setTotalLectures(String.valueOf((int)j)));
                attn_percent = ((i/j)*100);
                holder.attnbar.setProgress((int) attn_percent);
                holder.totalpercent.setText(atndetails.setAttendancePercent(String.valueOf((int) attn_percent)));
                myRef.child("AttendanceDetails").child(atndetails.getSubjectName()).child("totalAttended").setValue(atndetails.setTotalAttended(String.valueOf((int)i)));
                myRef.child("AttendanceDetails").child(atndetails.getSubjectName()).child("totalLecs").setValue(atndetails.setTotalLectures(String.valueOf((int)j)));
                myRef.child("AttendanceDetails").child(atndetails.getSubjectName()).child("attendancePercent").setValue(atndetails.setAttendancePercent(String.valueOf((int) attn_percent)));

            }
        });
    }

    @Override
    public int getItemCount() {
        return details.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{
        //final AttendanceDetails attendanceDetails = new AttendanceDetails(subname.getText().toString(),totalAttended.getText().toString(),totalLecs.getText().toString(),totalpercent.getText().toString());
        public TextView subname,attn,totalAttended,totalLecs,slash1,totalpercent;
        public ImageButton presentbtn, absentbtn;
        public ProgressBar attnbar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.attnbar = itemView.findViewById(R.id.attn_progress);
            this.totalpercent = itemView.findViewById(R.id.attn_percent);
            this.subname =itemView.findViewById(R.id.subname);
            this.attn =itemView.findViewById(R.id.num_of_days);
            this.slash1 = itemView.findViewById(R.id.slash);
            this.totalAttended =itemView.findViewById(R.id.attended);
            this.totalLecs =itemView.findViewById(R.id.totallecs);
            this.presentbtn = itemView.findViewById(R.id.present);
            this.absentbtn = itemView.findViewById(R.id.absent);

        }


    }
}
