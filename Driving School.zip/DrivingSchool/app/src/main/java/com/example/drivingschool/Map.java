package com.example.drivingschool;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;

public class Map extends Fragment {

    DrawerLayout drawerLayout;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReference;
    private Button map_btn, retrive_btn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_map, container, false);
//        viewPager = (ViewPager) rootView .findViewById(R.id.viewPager);
        drawerLayout = rootView.findViewById(R.id.drawer_layout);

        map_btn = rootView.findViewById(R.id.map_btn);
        retrive_btn = rootView.findViewById(R.id.retrive_btn);
        map_btn.setOnClickListener((View.OnClickListener) this);
        retrive_btn.setOnClickListener((View.OnClickListener) this);

        return rootView;
    }

    //@Override
    public void onClick(View v) {
        Intent c, c1;
        switch (v.getId()) {
            case R.id.map_btn : c = new Intent(getContext(), MapsActivity.class); startActivity(c); break;
            case R.id.retrive_btn : c1 = new Intent(getContext(), RetriveMapsActivity.class); startActivity(c1); break;
            default: break;
        }
    }

//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//    }
}



