package com.example.drivingschool;

public class SpaceprobeCar {

    String cr_id, cr_name, cr_rating;

    public String getCr_id() {
        return cr_id;
    }

    public void setCr_id(String cr_id) {
        this.cr_id = cr_id;
    }

    public String getCr_name() {
        return cr_name;
    }

    public void setCr_name(String cr_name) {
        this.cr_name = cr_name;
    }

    public String getCr_rating() {
        return cr_rating;
    }

    public void setCr_rating(String cr_rating) {
        this.cr_rating = cr_rating;
    }
}
