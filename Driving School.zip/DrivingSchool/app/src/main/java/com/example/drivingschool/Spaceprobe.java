package com.example.drivingschool;

public class Spaceprobe {

    String tr_id, tr_name, tr_rating;

    public String getTr_id() {
        return tr_id;
    }

    public String getTr_name() {
        return tr_name;
    }

    public String getTr_rating() {
        return tr_rating;
    }

    public void setTr_id(String tr_id) {
        this.tr_id = tr_id;
    }

    public void setTr_name(String tr_name) {
        this.tr_name = tr_name;
    }

    public void setTr_rating(String tr_rating) {
        this.tr_rating = tr_rating;
    }
}
