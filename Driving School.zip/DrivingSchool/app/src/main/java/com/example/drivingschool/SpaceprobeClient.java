package com.example.drivingschool;

public class SpaceprobeClient {

    String cl_id, cl_name, cl_session;

    public String getCl_id() {
        return cl_id;
    }

    public void setCl_id(String cl_id) {
        this.cl_id = cl_id;
    }

    public String getCl_name() {
        return cl_name;
    }

    public void setCl_name(String cl_name) {
        this.cl_name = cl_name;
    }

    public String getCl_session() {
        return cl_session;
    }

    public void setCl_session(String cl_session) {
        this.cl_session = cl_session;
    }
}
